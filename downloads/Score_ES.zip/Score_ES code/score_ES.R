### Source code for 'Inference for Joint Quantile and Expected Shortfall Regression'
### Author: Xiang Peng
###         Merck Research Laboratories, Merck & Co
### Last Modified On: Sep. 17th, 2022

# Note: R package 'esreg' is required 

############## Separate ES regression ##############
sep.esreg.fit <- function(xq, xe, y, alpha, g2=1, early_stopping, 
                          lower.tail = FALSE) {
  # xq (xe): design matrix WITHOUT the intercept term for quantile (ES) regression
  # y: response vector
  # alpha: probability level
  # g2: specifies the choice of the specification function G2()
  #     can take values: 1, 2, 3, 4, 5 (same as the 'g2' arguments of esreg::esreg), defaults to 1
  # early_stopping: stop the iterated local search if there is no improvement in early_stopping steps
  # lower.tail: logical; if FALSE (default), the upper tail ES regression will be fitted
  t0 <- Sys.time()
  xq = as.matrix(xq); xe = as.matrix(xe)
  xq <- cbind(1, xq); xe <- cbind(1, xe) # add intercept
  kq <- ncol(xq); ke <- ncol(xe)
  
  # transfom the data if we focus on the upper tail expected shortfall
  if(!lower.tail){
    alpha = 1-alpha; y = -y
  }
  
  # Check input parameters and data
  if (!(g2 %in% c(1, 2, 3, 4, 5))) stop("G2 can be 1, 2, 3, 4 or 5.")
  if ((alpha < 0) | (1 < alpha)) stop("alpha not in (0, 1)")
  if (any(is.na(y)) | any(is.na(xq)) | any(is.na(xe)))
    stop("Data contains NAs!")
  if (!(all(is.finite(y)) & all(is.finite(xq)) & all(is.finite(xe))))
    stop("Not all values are finite!")
  if (length(y) != nrow(xq))
    stop("Dimensions of y and xq do not match!")
  if (length(y) != nrow(xe))
    stop("Dimensions of y and xe do not match!")
  
  # support of G_2 is negative when g2 in c(1, 2, 3)
  if (g2 %in% c(1, 2, 3)) {
    max_y <- max(y); mad_y = mad(y)/2
    y <- y - (max_y + mad_y)
  }
  
  ## Find starting values
  # Match quantile and expected shortfall levels under normality
  e <- -stats::dnorm(stats::qnorm(alpha))/alpha
  alpha_tilde <- stats::uniroot(function(x) stats::qnorm(x) - e, c(0, alpha))$root
  
  # Fit the quantile regression
  fit_qr_q <- suppressWarnings(quantreg::rq(y ~ xq - 1, tau = alpha))
  fit_qr_e <- suppressWarnings(quantreg::rq(y ~ xe - 1, tau = alpha_tilde))
  
  # Get standard errors for the perturbation
  qr_sum_e <- suppressWarnings(summary(fit_qr_e, se="iid"))
  se_e <- qr_sum_e$coefficients[,2]
  
  # Store the coefficient estimates and fitted value from quantile regression model
  yhatq <- fit_qr_q$fitted.values
  bq0 <- fit_qr_q$coef
  be0 <- fit_qr_e$coef
  
  # If G2 is 1, 2, 3 ensure that x'be < 0 by moving the es intercept
  if (g2 %in% c(1, 2, 3)) {
    max_xe <- max(xe %*% be0)
    be0[1] <- be0[1] - (max_xe + 0.1) * (max_xe >= -0.1)
  }
  
  # Set the target function
  fun <- function(be) suppressWarnings(
    sep_esr_rho(be = be, yhatq = yhatq, y = y, xe = xe, alpha = alpha, g2 = g2)
  )
  
  ## Optimize the model using iterated local search
  # Initial optimization
  fit <- try(stats::optim(par = be0, fn = fun, method = "Nelder-Mead",
                          control = list(maxit = 2000)), silent = TRUE)
  
  # Counts the iterations without decrease of the loss
  counter <- 0
  while (counter < early_stopping) {
    # Perturbe b
    bet <- fit$par + stats::rnorm(ke, sd=se_e)
    
    # If G2 is 1, 2, 3 ensure that x'be < 0 by moving the es intercept
    if (g2 %in% c(1, 2, 3)) {
      max_xe <- max(xe %*% bet)
      bet[1] <- bet[1] - (max_xe + 0.1) * (max_xe >= 0)
    }
    
    # Fit the model with the perturbed parameters
    tmp_fit <- try(stats::optim(par = bet, fn = fun, method = "Nelder-Mead",
                                control = list(maxit = 2000)), silent = TRUE)
    
    # Replace the fit if the new loss is smaller than the old. Otherwise increase the counter.
    if (!inherits(tmp_fit, "try-error")) {
      if (tmp_fit$value < fit$value) {
        fit <- tmp_fit
        counter <- 0
      } else {
        counter <- counter + 1
      }
    }
  }
  
  # Set names of the parameters
  fit_par = c(bq0, fit$par)
  names(fit_par) <- c(paste0("bq_", 1:kq - 1), paste0("be_", 1:ke - 1))
  
  # Undo the transformation
  if (g2 %in% c(1, 2, 3)) {
    y <- y + max_y + mad_y
    fit_par[1] <- fit_par[1] + max_y + mad_y
    fit_par[kq+1] <- fit_par[kq+1] + max_y + mad_y
  }
  
  # undo the transformation for upper expected shortfall
  if(!lower.tail) {
    fit_par = -fit_par; alpha = 1-alpha; y = -y
  }
  
  # Return results
  revtal <- list(
    coefficients   = fit_par, # all regression coefficients
    coefficients_q = fit_par[1:kq], # quantile regression coefficients
    coefficients_e = fit_par[(kq+1):(kq+ke)], # ES regression coefficients
    y              = y,
    xq             = xq, # design matrix WITH the intercept term
    xe             = xe,
    alpha          = alpha,
    g2             = g2,
    lower.tail     = lower.tail,
    early_stopping = early_stopping,
    loss           = fit$value, # value of the loss function evaluated with the fitted coefficients
    time           = Sys.time() - t0
  )
  
  revtal
}


################ Hypothesis Testing ###############
# Score test for H_0: \theta_2^e = theta in the model:
# Q_\tau(Y | X_q) = X_q' \theta^q  ES_\tau(Y | W, Z) = W'\theta_1^e + Z'\theta_2^e
# Assuming \theta_1^e ALWAYS include the intercept 
score.sepes.test = function(xq, w, z, theta = 0, y, alpha, g2, early_stopping, 
                            lower.tail = FALSE, sigma_est = 'nid'){
  # xq and w are design matrices (under H_0) WITHOUT the intercept term
  # default value of theta is zero
  # sigma_est: ind or nid; specify the method to estimate the conditional variance of y given xq and y < 0
  
  # Transform y such that the hypothesis is equivalent to test H_0: \theta_2^e = 0 with the new response
  y = y - as.matrix(z) * theta
  
  # fit separate ES regression under both null and alternative, and extract elements
  sepfit_null = sep.esreg.fit(xq=xq, xe=w, y=y, alpha=alpha, g2=g2, 
                              early_stopping=early_stopping, lower.tail=lower.tail)
  sepfit_alt = sep.esreg.fit(xq=xq, xe=cbind(w, z), y=y, alpha=alpha, g2=g2, 
                             early_stopping=early_stopping, lower.tail=lower.tail)
  y = sepfit_null$y; n = length(y); alpha <- sepfit_null$alpha
  
  # quantile design matrix and coef
  xq = sepfit_null$xq; kq <- ncol(xq)
  coefficients_q <- sepfit_null$coefficients_q
  
  # ES design matrix and coef under H_a
  xe = sepfit_alt$xe; ke <- ncol(xe)
  coefficients_e <- sepfit_alt$coefficients_e
  
  # ES design matrix and coef under H_0
  xw = sepfit_null$xe; kw = ncol(xw)
  coefficients_w = sepfit_null$coefficients_e
  
  # transform the elements if we focus on the upper tail expected shortfall
  lower.tail = sepfit_null$lower.tail
  if(!lower.tail){
    alpha = 1-alpha; y = -y
    coefficients_e = -coefficients_e
    coefficients_q = -coefficients_q
    coefficients_w = -coefficients_w
  }
  
  # If G2 is 1, 2, 3 ensure that w'bw < 0 by moving the es intercept
  if (sepfit_null$g2 %in% c(1, 2, 3)) {
    max_y <- max(y); mad_y = mad(y)/2
    y <- y - (max_y + mad_y)
    coefficients_q[1] <- coefficients_q[1] - (max_y + mad_y)
    coefficients_e[1] <- coefficients_e[1] - (max_y + mad_y)
    coefficients_w[1] <- coefficients_w[1] - (max_y + mad_y)
  }
  
  # Precompute some quantities
  xbq <- as.numeric(xq %*% coefficients_q)
  xbe <- as.numeric(xe %*% coefficients_e)
  xbw <- as.numeric(xw %*% coefficients_w)
  uq <- as.numeric(y - xbq)
  G2_prime_xw <- G_vec(z = xbw, g = "G2_prime", type = sepfit_null$g2)
  G = diag(G2_prime_xw)
  
  # Check the methods in case of sample quantile / es
  if ((kq == 1) & sigma_est != "ind") {
    warning("Changed conditional truncated variance estimation to ind!")
    sigma_est <- "ind"
  }
  
  # orthogonal transformation
  xwG = t(xw) %*% G %*% xw
  xwG_inv = mat_inverse_decomp(m = xwG)
  zstar = z - xw %*% xwG_inv %*% t(xw) %*% G %*% z
  
  # calculate score test stat. and var. without loops
  h = I(y <= xbq)
  scores = zstar * G2_prime_xw * (xbw - xbq + (xbq - y) * h / alpha)
  score.stat = colSums(as.matrix(scores)) / sqrt(n)
  
  # Estimate the (conditional) truncated variance with specifc method
  cv <- conditional_truncated_variance(y = uq, x = xq, approach = sigma_est)
  
  # calculate score stat. var.
  zzstar = zstar * sqrt((G2_prime_xw)^2 * (cv/alpha + (1-alpha)/alpha * (xbq - xbe)^2))
  score.stat.var = t(zzstar) %*% zzstar / n
  
  # we focus on the coef of treatment indicator, so score.stat is a scalar
  test.stat = score.stat / sqrt(score.stat.var)
  pval = 2 * (1 - pnorm(abs(test.stat)))
  
  # summarize results
  sum_re = cbind(score.stat, score.stat.var, test.stat, pval)
  colnames(sum_re) = c("score", "score.var", "test.stat", "pval")
  rownames(sum_re) = sigma_est
  
  return(list(sum_re = sum_re,
              score.stat = score.stat,
              score.stat.var = score.stat.var,
              test.stat = test.stat,
              pval = pval))
}


############### CI Construction for ES regression coefficients ###############
# CI  of \theta_2^e constructed by inversion of score test in the model
# ES_\tau(Y | W, Z) = W'\theta_1^e + Z'\theta_2^e
# Assuming \theta_1^e ALWAYS include the intercept term
# CI is built for each par separately
score.sepes.ci = function(xq, w, z, y, alpha, g1=2, g2=1, early_stopping,
                          signif.level = .05,
                          lower.tail = FALSE, sigma_est = 'nid'){
  # g1, g2: same as the parameters g1 and g2 used in esreg::esreg function, 
  #         which specify the choice of specification functions used in the joint estimation
  # signif.level: significance level of CI
  
  kw = ncol(as.matrix(w))
  z = as.matrix(z); kz = ncol(z)
  xe = cbind(w, z)
  re = matrix(NA, nrow = kz, ncol = 3)
  
  # first get initial value and var by joint ES regression
  jointfit = joint.esreg.fit(xq=xq, xe=xe, y=y, alpha=alpha, g1=g1, g2=g2, 
                             early_stopping=early_stopping, 
                             lower.tail = lower.tail)
  vcov = vcov.joint.esreg(jointfit, method = "asymptotic", sigma_est = 'ind')
  kq = ncol(jointfit$xq)
  
  # initial values and sd
  theta0 = jointfit$coefficients_e[-(1:(kw+1))]
  sd = sqrt(diag(vcov))[-(1:(kq+kw+1))]
  
  for (i in 1:kz) {
    temp_theta = theta0[i]
    temp_sd = sd[i]
    
    # search for the right end of the interval
    t1 = temp_theta
    t2 = temp_theta + 5*temp_sd
    dif1 = t2 - t1
    tol = 1e-08
    while(dif1>tol)
    {
      tt = (t1+t2)/2
      ystar = y - z[,i] * tt
      zstar = z[,i]
      # perform score test under the restricted model under H0: z(i) = tt
      test.re = score.sepes.test(xq=xq, w=cbind(w, z[,-i]), z=zstar, theta=tt,
                                 y=y, alpha=alpha, g2=g2, 
                                 early_stopping=early_stopping, lower.tail = lower.tail, 
                                 sigma_est = sigma_est)
      # if reject H_0, then tt is not in the CI, we can set the upper limit as tt
      if(test.re$pval < signif.level) t2 = tt
      # if we fail to reject H_0, then tt is in the CI, we can set the lower limit as tt
      if(test.re$pval >= signif.level) t1 = tt
      dif1 = t2-t1
    }
    re[i, 3] = (t1+t2)/2
    
    # search for the left end of the interval
    t1 = temp_theta
    t2 = temp_theta - 5*temp_sd
    dif1 = t1 - t2
    tol = 1e-08
    while(dif1>tol)
    {
      tt = (t1+t2)/2
      ystar = y - z[,i] * tt
      zstar = z[,i]
      # perform score test under the restricted model under H0: z(i) = tt
      test.re = score.sepes.test(xq=xq, w=cbind(w, z[,-i]), z=zstar, theta=tt,
                                 y=y, alpha=alpha, g2=g2, 
                                 early_stopping=early_stopping, lower.tail = lower.tail, 
                                 sigma_est = sigma_est)
      # if reject H_0, then tt is not in the CI, we can set the upper limit as tt
      if(test.re$pval < signif.level) t2 = tt
      # if we fail to reject H_0, then tt is in the CI, we can set the lower limit as tt
      if(test.re$pval >= signif.level) t1 = tt
      dif1 = t1-t2
    }
    re[i, 2] = (t1+t2)/2
  }
  
  # obtain coef estimates with separate ES regression
  sepfit = sep.esreg.fit(xq=xq, xe=xe, y=y, alpha=alpha, g2=g2, 
                         early_stopping=early_stopping, 
                         lower.tail = lower.tail)
  re[, 1] = sepfit$coefficients_e[-(1:(kw+1))]
  colnames(re) = c("coef", "lb", "ub")
  rownames(re) = names(z)
  
  return(re)
}


############## Joint ES regression (based on esreg::esreg function) ##############
joint.esreg.fit = function(xq, xe, y, alpha, g1, g2, early_stopping, 
                           lower.tail = FALSE){
  xq = as.matrix(xq); xe = as.matrix(xe)
  # transfom the data if we focus on the upper tail expected shortfall
  if(!lower.tail){
    alpha = 1-alpha; y = -y
  }
  
  revtal = esreg::esreg(xq=xq, xe=xe, y=y, alpha=alpha, g1=g1, g2=g2, 
                        early_stopping=early_stopping)
  revtal$lower.tail = lower.tail
  
  # undo the transformation for upper expected shortfall
  if(!lower.tail) {
    revtal$coefficients = -revtal$coefficients
    revtal$coefficients_q = -revtal$coefficients_q
    revtal$coefficients_e = -revtal$coefficients_e
    revtal$alpha = 1-alpha; revtal$y = -y
  }
  
  revtal
}

######### Covariance Estimation for joint ES regression coefficients ##########

# If method = 'asymptotic', need further specify sigma_est
# If method = 'boot', need further specify B (number of bootstrap)
vcov.joint.esreg = function(object, method='asymptotic', sigma_est = "ind", B = 1000){
  # transfom the data if we focus on the upper tail expected shortfall
  if(!object$lower.tail){
    object$coefficients = -object$coefficients
    object$coefficients_q = -object$coefficients_q
    object$coefficients_e = -object$coefficients_e
    object$alpha = 1-object$alpha; object$y = -object$y
  }
  
  # The upper tail ES and the lower tail has the same variance
  if(method == "asymptotic") cov = esreg::vcovA(object=object, sigma_est = sigma_est)
  if(method == "boot") cov = esreg::vcovB(object=object, B = B)
  
  cov
}


######### Estimating the conditional truncated variance: y given x and given y <= 0 ##########
# approach: ind or nid
# y: Vector of dependent data
# x: Matrix of covariates including the intercept
conditional_truncated_variance <- function(y, x, approach) {
  if (sum(y <= 0) <= 2) {
    stop("Not enough negative quantile residuals!")
    #cv = NA
  }
  
  if (approach == "ind") {
    cv <- rep(stats::var(y[y <= 0]), length(y))
  } else if (is.element(approach, c("nid", "scl_sp"))){
    cv <- tryCatch({
      # Get conditional mean and sigma
      mu_sigma <- conditional_mean_sigma(y, x)
      mu <- mu_sigma$mu
      sigma <- mu_sigma$sigma
      
      # Truncated conditional variance
      # Kernel density estimate of the standardized residuals
      df <- stats::density((y - mu) / sigma, bw = "SJ")
      lower_int_boundary <- min(df$x)
      pdf <- stats::approxfun(df, yleft = 0, yright = 0)
      
      # Truncation points
      beta <- -mu / sigma
      
      # Integrate the truncated pdf by the trapezoidal rule
      div <- 1000
      h <- (max(beta) - lower_int_boundary) / (div - 1)
      b_approx <- seq(lower_int_boundary, max(beta) + h, h)
      midpoint <- b_approx[-div] + h/2
      y0 <- pdf(b_approx)
      y1 <- b_approx * y0
      y2 <- b_approx^2 * y0
      cb <- cumsum(y0[-1] + y0[-div]) / 2 * h # cdf's
      m1 <- cumsum(y1[-1] + y1[-div]) / 2 * h
      m2 <- cumsum(y2[-1] + y2[-div]) / 2 * h
      cv_approx <- m2 / cb - (m1 / cb)^2
      cv_approx[cv_approx < 0] <- NA  # conditional variance can not be negtive
      
      # Approximate the conditional truncated variance
      cv <- sigma^2 * stats::approx(x = midpoint, y = cv_approx, xout = beta)$y
      
      if (any(is.na(cv)) | any(!is.finite(cv)) | any(cv < 0)) stop() else cv
    }, error = function(e) {
      warning(paste0("Can not fit the ", approach, " estimator, switching to the ind approach!"))
      rep(stats::var(y[y <= 0]), length(y))
    })
  }
  
  cv
}


# Conditional Mean and Sigma
# Estimate the conditional mean and sigma of the dependent data conditional on covariates x
# y: Vector of dependent data
# x: Matrix of covariates including the intercept
conditional_mean_sigma <- function(y, x) {
  # Starting values and ensure positive fitted standard deviations
  fit1 <- stats::lm(y ~ x - 1)
  fit2 <- stats::lm(abs(fit1$residuals) ~ x - 1)
  fit2$coefficients[1] <- fit2$coefficients[1] - min(0.001, min(fit2$fitted.values))
  b0 <- c(fit1$coefficients, fit2$coefficients)
  
  # Estimate the model under normality
  ll <- function(par, y, x) {
    k <- ncol(x)
    mu <- as.numeric(x %*% par[1:k])
    sigma <- as.numeric(x %*% par[(k+1):(2*k)])
    ifelse(all(sigma > 0), -sum(stats::dnorm(x=y, mean=mu, sd=sigma, log=TRUE)), NA)
  }
  fit <- try(stats::optim(b0, function(b) ll(par=b, y=y, x=x), method="BFGS"), silent=TRUE)
  if(inherits(fit, "try-error") || (fit$convergence != 0)) {
    fit <- try(stats::optim(b0, function(b) ll(par=b, y=y, x=x), method="Nelder-Mead",
                            control=list(maxit=10000)), silent=TRUE)
  }
  if(inherits(fit, "try-error") || (fit$convergence != 0)) {
    stop("Cannot fit the model!")
  }
  b <- fit$par
  
  # Estimated means and standard deviations
  k <- ncol(x)
  mu <- as.numeric(x %*% b[1:k])
  sigma <- as.numeric(x %*% b[(k+1):(2*k)])
  
  list(mu = mu, sigma = sigma)
}


# Matrix spectral decomposition to approximate (Xw^T %*% G %*% Xw)^{-1}
# Replace the (nearly) zero eigenvalues by some small positive number
mat_inverse_decomp = function(m, replace_val = 0.0001){
  mat_decomp = eigen(m, symmetric = TRUE)
  Lambda = mat_decomp$values
  if(any(abs(Lambda) < replace_val)) {
    Lambda[abs(Lambda) < replace_val] = replace_val
    warning(paste("Eigenvalue close to zero, replaced by ", replace_val))
  }
  
  #print(Lambda)
  Lambda_inv = 1/Lambda
  m_inv = mat_decomp$vectors %*% diag(Lambda_inv) %*% t(mat_decomp$vectors)
  return(m_inv)
}

#################### Specification of G1 and G2 functions ####################
# G1(z) = z
# G1(z) = 0
G1_fun = function(z, type) {
  n = length(z)
  if (type == 1) {
    out = z
  } else if (type == 2) {
    out = rep(0, n)
  } else {
    stop("type not in 1, 2!")
  }
  return (out)
}

# G1_prime(z) = 1
# G1_prime(z) = 0
G1_prime_fun = function(z, type) {
  n = length(z)
  if (type == 1) {
    out = rep(1, n)
  } else if (type == 2) {
    out = rep(0, n)
  } else {
    stop("type not in 1, 2!")
  }
  return (out)
}


# G1_prime(z) = 0
# G1_prime(z) = 0
G1_prime_prime_fun = function(z, type) {
  n = length(z)
  if (type == 1) {
    out = rep(0, n)
  } else if (type == 2) {
    out = rep(0, n)
  } else {
    stop("type not in 1, 2!")
  }
  return (out)
}


# Choice of the G2_curly function:
# 1: -log(-z), z < 0
# 2: -sqrt(-z), z < 0
# 3: -1/z, z < 0
# 4: log(1 + exp(z))
# 5: exp(z)
G2_curly_fun = function(z, type) {
  n = length(z)
  if ((type == 1) | (type == 2) | (type == 3)) {
    if (any(z>=0)) {
      warning("z can not be positive for type 1, 2, 3!")
      return(rep(NA, n))
    }
  }
  if (type == 1) {
    out = -log(-z)
  } else if (type == 2) {
    out = -sqrt(-z)
  } else if (type == 3) {
    out = -1/z
  } else if (type == 4) {
    out = log(1 + exp(z)) } else if (type == 5) {
      out = exp(z)
    } else {
      stop("type not in 1, 2, 3, 4, 5!")}
  return (out)
}


# Choice of the G2 function:
# 1: -1/z, z < 0
# 2: 0.5/sqrt(-z), z < 0
# 3: 1/z^2, z < 0
# 4: 1 / (1 + exp(-z))
# 5: exp(z)
G2_fun = function(z, type) {
  n = length(z)
  if ((type == 1) | (type == 2) | (type == 3)) {
    if (any(z>=0)) {
      warning("z can not be positive for type 1, 2, 3!")
      return (rep(NA, n))
    }
  }
  if (type == 1) {
    out = -1/z
  } else if (type == 2) {
    out = 0.5/sqrt(-z)
  } else if (type == 3) {
    out = 1/z^2
  } else if (type == 4) {
    out = 1/(1 + exp(-z))
  } else if (type == 5) {
    out = exp(z)
  } else {
    stop("type not in 1, 2, 3, 4, 5!")
  }
  return (out)
}


# Choice of the G2_prime function:
# 1: 1/z^2, z < 0
# 2: 0.25 / (-z)^(3/2), z < 0
# 3: -2/z^3, z < 0
# 4: exp(z) / (1 + exp(z))^2
# 5: exp(z)
G2_prime_fun = function(z, type) {
  n = length(z)
  if ((type == 1) | (type == 2) | (type == 3)) {
    if (any(z>=0)) {
      warning("z can not be positive for type 1, 2, 3!")
      return (rep(NA, n))
    }
  }
  if (type == 1) {
    out = 1/z^2
  } else if (type == 2) {
    out = 0.25/(-z)^1.5
  } else if (type == 3) {
    out = -2/z^3
  } else if (type == 4) {
    out =  exp(z) / (1 + exp(z))^2
  } else if (type == 5) {
    out = exp(z)
  } else {
    stop("type not in 1, 2, 3, 4, 5!")
  }
  return (out)
}


# Choice of the G2_prime_prime function:
# 1: -2/z^3, z < 0
# 2: 0.375 / (-z)^(5/2), z < 0
# 3: 6/z^4, z < 0
# 4: -(exp(z) * (exp(z) - 1)) / (exp(z) + 1)^3
# 5: exp(z)
G2_prime_prime = function(z, type) {
  n = length(z)
  if ((type == 1) | (type == 2) | (type == 3)) {
    if (any(z>=0)) {
      warning("z can not be positive for type 1, 2, 3!")
      return (rep(NA, n))
    }
  }
  if (type == 1) {
    out = -1/z^3
  } else if (type == 2) {
    out = 0.375/(-z)^2.5
  } else if (type == 3) {
    out = 6/z^4
  } else if (type == 4) {
    out =  -(exp(z) * (exp(z) - 1)) / (1 + exp(z))^3
  } else if (type == 5) {
    out = exp(z)
  } else {
    stop("type not in 1, 2, 3, 4, 5!")
  }
  return (out)
}


# g String, either G1, G1_prime, G2_curly, G2 or G2_curly
# type Numeric, for G1: 1-2; G2: 1-5
G_vec = function(z, g, type) {
  if (g == "G1") {
    out = G1_fun(z, type)
  } else if (g == "G1_prime") {
    out = G1_prime_fun(z, type)
  } else if (g == "G1_prime_prime") {
    out = G1_prime_prime_fun(z, type)
  } else if (g == "G2_curly") {
    out = G2_curly_fun(z, type)
  } else if (g == "G2") {
    out = G2_fun(z, type)
  } else if (g == "G2_prime") {
    out = G2_prime_fun(z, type)
  } else if (g == "G2_prime_prime") {
    out = G2_prime_prime(z, type)
  } else {
    stop("Non supported G-function!")
  }
  return (out)
}

#################### plug-in loss function of ES given quantile fitted values ####################
sep_esr_rho = function(be, yhatq, y, xe, alpha, g2){
  # be: ES regression coefficients
  # yhatq: quantile fitted values
  # y: response vector
  # xe: design matrix of ES (including the intercept)
  # alpha: probability level
  xbe <- as.numeric(xe %*% be)
  
  if (((g2 == 1) | (g2 == 2) | (g2 == 3)) & (any(xbe >= 0))) {
    warning("x'b_e can not be positive for g2 1, 2, 3!")
    return (NA)
  }
  
  G2_xe <- G_vec(z = xbe, g = "G2", type = g2)
  G2_curly_xe = G_vec(z = xbe, g = "G2_curly", type = g2)
  re = G2_xe * (xbe - yhatq + (yhatq - y) * I(y <= yhatq) / alpha) - G2_curly_xe
  return(sum(re))
}
