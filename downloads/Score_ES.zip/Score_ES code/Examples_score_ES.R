### Examples of simulations for using the functions in 'Inference for Joint Quantile and Expected Shortfall Regression'
### Author: Xiang Peng
###         Merck Research Laboratories, Merck & Co
### Last Modified On: Spe. 17th, 2022

source("score_ES.R")

#######################################################################
# Below code covers all simulation scenarios considered in the paper, #
# for illustration purpose, we take Scenario 3 as an example.         #
#######################################################################

# sample size in each treatment group
n_ss = 100
# quantile of interest
tau = 0.8

# set initial seed
set.seed(0)

# generate data
D = c(rep(0, n_ss), rep(1, n_ss))
C = c(truncnorm::rtruncnorm(n_ss,a=-.5, mean=0,sd=.5), truncnorm::rtruncnorm(n_ss,a=-.5, mean=.5,sd=.5))
x1 = rnorm(2 * n_ss, mean = 2.5, sd = .5)
x2 = rbinom(2*n_ss, 1, .4)
x3 = rlnorm(2*n_ss); x4 = rlnorm(2*n_ss)
x56 = MASS::mvrnorm(2*n_ss, c(1, 1), matrix(c(1, .8, .8, 1), nrow = 2))
x5 = x56[, 1]; x6 = x56[, 2]
x7 = rchisq(2*n_ss, df=1)
eps = rnorm(2*n_ss)

# # Scenario 1 in the paper
# eta = 1.35 # signal of treatment
# Y = 5 + eta * D + x1 + eps
# X = cbind(D, x1)

# # Scenario 2 in the paper
# eta = 2 # signal of treatment
# Y = 5 - eta * D + C + eps*(1 + .25*D + 2*C)
# X = cbind(D, C)

# Scenario 3 in the paper
eta = 2.5 # signal of treatment
Y = 5 + eta * D + x2 + x3 + x4 + x5 + x6 + x7 + eps
X = cbind(D, x2, x3, x4, x5, x6, x7)

# # Scenario 4 in the paper
# eta = 3.5 # signal of treatment
# eps = rt(2*n_ss, df=3) * .5
# Y = 5 + eta * D + x2 + x3 + x4 + x5 + x6 + x7 + eps*(1 + .2*D)
# X = cbind(D, x2, x3, x4, x5, x6, x7)

# separate ES regression
sep_fit = sep.esreg.fit(xq=X, xe=X, y=Y, alpha=tau, g2=1, 
                        early_stopping=10, lower.tail = FALSE)
sep_fit$coefficients_q # quantile regression coefs, true bq_1 (quantile treatment effect) is 2.5
sep_fit$coefficients_e # ES regression coefs, true be_1 (ES treatment effect) is 2.5


# score test of treatment effect with ind method
score_HT_ind = score.sepes.test(xq=X, w=X[, -1], z=D, y=Y, alpha=tau, g2=1, 
                                early_stopping=10, sigma_est = 'ind')
score_HT_ind$sum_re
# score test of treatment effect with nid method
score_HT_nid = score.sepes.test(xq=X, w=X[, -1], z=D, y=Y, alpha=tau, g2=1, 
                                early_stopping=10, sigma_est = 'nid')
score_HT_nid$sum_re


# score CI of treatment parameter with ind method
score_CI_ind = score.sepes.ci(xq=X, w=X[, -1], z=D, y=Y, alpha=tau, g1=2, g2=1, 
                              early_stopping=10, sigma_est = "ind")
score_CI_ind
# score CI of treatment parameter with nid method
score_CI_nid = score.sepes.ci(xq=X, w=X[, -1], z=D, y=Y, alpha=tau, g1=2, g2=1, 
                              early_stopping=10, sigma_est = "nid")
score_CI_nid



