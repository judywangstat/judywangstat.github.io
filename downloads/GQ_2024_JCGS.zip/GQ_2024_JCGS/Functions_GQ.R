### A Generalized Quantile Method for Subgroup Identification (source functions)
### Author: Xiang Peng
###         Department of Statistics, George Washington University
### Last Modified On: Jun. 1st, 2021

library(stringr)
library(quantreg)
library(dagR)

alt.matrix = function(Z, can.sp.var){
  # Obtain the design matrix under the null and alternative models, used in rank score test
  # Z: binary trt indicator
  # can.sp.var: candidate split variable
  
  if(is.factor(can.sp.var)){
    p = length(levels(can.sp.var)) - 1; n = length(can.sp.var)
    level.m = matrix(0, nrow = n, ncol = p)
    for (i in 1:n) {
      if(as.numeric(can.sp.var[i])>1){level.m[i, as.numeric(can.sp.var[i])-1] = 1}
    }
  }else{
    qx <- quantile(can.sp.var, probs = c(0.25,0.5,0.75))
    level.m <- cbind(can.sp.var>=qx[1]&can.sp.var<qx[2], can.sp.var>=qx[2]&can.sp.var<qx[3], can.sp.var>=qx[3])
  }
  # delete missing columns
  level.m <- level.m[ ,!apply(level.m, 2, function(x) all(x == 0)), drop = FALSE]
  alt.m = Z * level.m
  
  return(list(alt.m = alt.m, level.m = level.m))
}


WM.p <- function(teststat, df){
  # convert chi-squared test statistic to a 1-df chi-squared statistic, p-val is returned
  Wm.Z = (7 / 9) + sqrt(df) * ((teststat / df)^{1/3} - 1 + (2 / (9*df)))
  Wm.Z = Wm.Z^3; Wm.Z = max(0,Wm.Z)
  stats <- Wm.Z
  return(pchisq(stats, 1, lower.tail = FALSE))
}


rq.test.rank.modified = function (x0, x1, y, score = "wilcoxon", trim = NULL) 
{ 
  # modified version of rq.test.rank function in quantreg package
  # x0: design matrix for the null component of the rank score test
  # x1: design matrix for the alternative component of the rank score test
  # y: response vector
  # score: score function used in the rank test (including the "adaptive" method)
  # trim: optional trimming parameters – only applicable for the Wilcoxon score
  n <- length(y)
  if (score == "adaptive"){
    v <- rq(y ~ x0 - 1, tau = -1)
    r1 <- ranks(v, "wilcoxon", tau=.5, trim = NULL)
    r2 <- ranks(v, "normal", tau=.5, trim = NULL)
    r3 <- ranks(v, "halfnormalscale", tau=.5, trim = NULL)
    r4 <- ranks(v, "wilcoxon", tau=.5, trim = c(.6, .95))
  }
  else {
    v <- rq(y ~ x0 - 1, tau = -1)
    r <- ranks(v, score, tau, trim)
  }
  x1hat <- as.matrix(qr.resid(qr(x0), x1))
  ndf <- NCOL(x1); delta0 = rep(0, NCOL(x1))
  ddf <- length(y) - NCOL(x0) - NCOL(x1)
  if(score == "adaptive"){
    T1 <- as.matrix(t(x1hat) %*% r1$ranks);T1 <- t(T1) %*% solve(crossprod(x1hat)) %*% T1/r1$A2
    T2 <- as.matrix(t(x1hat) %*% r2$ranks);T2 <- t(T2) %*% solve(crossprod(x1hat)) %*% T2/r2$A2
    T3 <- as.matrix(t(x1hat) %*% r3$ranks);T3 <- t(T3) %*% solve(crossprod(x1hat)) %*% T3/r3$A2
    T4 <- as.matrix(t(x1hat) %*% r4$ranks);T4 <- t(T4) %*% solve(crossprod(x1hat)) %*% T4/r4$A2
    Tn = c(T1, T2, T3, T4); A2 = c(r1$A2, r2$A2, r3$A2, r4$A2); tidx = which.max(Tn)
    Tn = max(Tn) / ndf; ncp <- t(delta0) %*% (crossprod(x1hat)/n) %*% delta0/A2[tidx]
    pvalue <- 1 - pf(Tn, ndf, ddf, ncp)
  }else {
    Tn <- as.matrix(t(x1hat) %*% r$ranks)
    Tn <- t(Tn) %*% solve(crossprod(x1hat)) %*% Tn/r$A2
    ncp <- t(delta0) %*% (crossprod(x1hat)/n) %*% 
      delta0/r$A2
    Tn <- Tn/ndf
    pvalue <- 1 - pf(Tn, ndf, ddf, ncp)
  }
  list(Tn = Tn, ndf = ndf, ddf = ddf, pvalue = pvalue)
}


sp.var.selection = function(dataset, score, trim = NULL){
  # dataset: first column is the treatment indicator Z, the second column is reseponse y, 
  #          the rest are the candidate split variables
  Tn = pval = c(); dataset = as.data.frame(dataset); n = nrow(dataset)
  Z = dataset[, 1]; Y = dataset[, 2]; n.sp.var = ncol(dataset) - 2
  
  for (i in 1:n.sp.var) {
    can.sp.var = dataset[, i+2]
    alt.m = alt.matrix(Z, can.sp.var)$alt.m
    nul.m = alt.matrix(Z, can.sp.var)$level.m
    nul.m = cbind(1, Z, nul.m)
    
    temp = try(rq.test.rank.modified(nul.m, alt.m, Y, score = score, trim = trim), silent = TRUE)
    
    if (class(temp) != "try-error"){
      pval[i] <- WM.p(temp$Tn * temp$ndf, temp$ndf); Tn[i] <- temp$Tn
    } else {
      pval[i] <- NA; Tn[i] <- NA
    }
  }
  return(list(Tn = Tn, pval = pval))
}


GQ_var_sle = function(train_data, score, trim = NULL){
  tt = sp.var.selection(train_data, score, trim)
  var.idx = which.min(tt$pval) + 2
  var = colnames(train_data)[var.idx]
  return(list(var.idx = var.idx, var=var))
}


quantloss <- function(r, tau){
  # quantile loss function
  # tau: vector of quantile levels
  # r: quantile residuals
  r = as.matrix(r); rho = c()
  for (i in 1:length(tau)) {
    rho <- c(rho, r[, i] * (tau[i] - I(r[, i] < 0)))
  }
  return(rho)
}


posi.pt = function(sv, quantile.pt, Y, Z){
  # generating possible split point: (1) continuous var, sample quantiles
  #                                  (2) catrgorical var, all possible combinations
  # sv: selected split variable
  # quantile.pt: quantile grids for generating split points of continuous split variables
  if(is.factor(sv)){
    sv.level = length(levels(sv))
    m = 2^{sv.level - 1} -1
    posi.pt = allCombs(1:sv.level, force = 1); posi.pt = posi.pt[1:m, , drop = FALSE]
  }else{
    posi.pt = quantile(sv, quantile.pt)
  }
  return(posi.pt)
}


sp.pt.selection = function(Y, Z, sv, taus = NULL, posi.pt, minbucket){
  # select split point (set) of the split variable
  # taus: quantile grids used in the composite quantile estimation
  # minbucket: smallest sample size of a treatment group
  nobj = length(Y); nl = c()
  
  if(is.factor(sv)){
    sv.level = length(levels(sv)); m = nrow(posi.pt)
    for (j in 1:m) {
      tt = charmatch(sv, na.omit(posi.pt[j, ])); t1 = ifelse(is.na(tt), 0, 1)
      Ltrtss = length(Y[Z == 1 & t1 == 1]); Lctlss = length(Y[Z == 0 & t1 == 1])
      Rtrtss = length(Y[Z == 1 & t1 == 0]); Rctlss = length(Y[Z == 0 & t1 == 0])
      n0 = min(Ltrtss, Lctlss, Rtrtss, Rctlss)
      if(n0 >= minbucket){
        # get the loss using sample quantile rather than fit regression
        L_trt_resid = outer(Y[Z == 1 & t1 == 1], quantile(Y[Z == 1 & t1 == 1], taus), "-")
        L_ctl_resid = outer(Y[Z == 0 & t1 == 1], quantile(Y[Z == 0 & t1 == 1], taus), "-")
        R_trt_resid = outer(Y[Z == 1 & t1 == 0], quantile(Y[Z == 1 & t1 == 0], taus), "-")
        R_ctl_resid = outer(Y[Z == 0 & t1 == 0], quantile(Y[Z == 0 & t1 == 0], taus), "-")
        Node_resid = rbind(L_trt_resid, L_ctl_resid, R_trt_resid, R_ctl_resid)
        nl[j] = sum(quantloss(Node_resid, taus))
      }else nl[j] = NA
    }
    
    if(any(is.numeric(nl))){
      idx = which.min(nl); sp <- paste(levels(sv)[na.omit(posi.pt[idx,])], collapse = "&")
      tt = charmatch(sv, na.omit(posi.pt[idx, ])); L.idx = which(!is.na(tt))
    }else{
      sp = NA; L.idx = NA
    }
  }else{
    n.pt <- length(posi.pt)
    for (j in 1:n.pt) {
      l = 0; t1 = I(sv <= posi.pt[j])
      Ltrtss = length(Y[Z == 1 & t1 == 1]); Lctlss = length(Y[Z == 0 & t1 == 1])
      Rtrtss = length(Y[Z == 1 & t1 == 0]); Rctlss = length(Y[Z == 0 & t1 == 0])
      n0 = min(Ltrtss, Lctlss, Rtrtss, Rctlss)
      if(n0 >= minbucket){
        # get the loss using sample quantile rather than fit regression
        L_trt_resid = outer(Y[Z == 1 & t1 == 1], quantile(Y[Z == 1 & t1 == 1], taus), "-")
        L_ctl_resid = outer(Y[Z == 0 & t1 == 1], quantile(Y[Z == 0 & t1 == 1], taus), "-")
        R_trt_resid = outer(Y[Z == 1 & t1 == 0], quantile(Y[Z == 1 & t1 == 0], taus), "-")
        R_ctl_resid = outer(Y[Z == 0 & t1 == 0], quantile(Y[Z == 0 & t1 == 0], taus), "-")
        Node_resid = rbind(L_trt_resid, L_ctl_resid, R_trt_resid, R_ctl_resid)
        nl[j] = sum(quantloss(Node_resid, taus))
      } else nl[j] = NA
    }
    
    if(any(is.numeric(nl))){
      idx = which.min(nl); sp <- posi.pt[idx]; L.idx = which(sv <= sp)
    }else{
      sp = NA; L.idx = NA
    }
  }
  return(list(sp = sp, L.idx = L.idx))
}


GQ_pt_sle = function(train_data){
  Z = train_data[, 1]; Y = train_data[, 2] 
  split_var = train_data[, 3]; pts = quantile(split_var, 1:19 * .05)
  tt = sp.pt.selection(Y, Z, split_var, 1:19 * .05, pts, 10)
  return(list(cut = tt$sp))
}


GQTE_test = function(Y, Z, weight = "supreme", bptime, seed = 314, n0 = 5){
  # weight: weight function considered in the GQTE estimator
  # bptime: number of bootstrap samples
  # n0: minimum sample size for one treatment group in the bootstrap sample
  n = length(Y)
  btheta.LW = btheta.HSN = btheta.TSW = c()
  base.dat = data.frame(y = Y, trt = Z)
  weights.abbr = c("LN", "LW", "HSN", "TSW")
  y.trt = Y[Z==1]; y.ctl = Y[Z==0]
  n.trt = length(y.trt); n.ctl = length(y.ctl)
  
  quant.vertex = function(n, weight){
    taus.vertex = c(0, 1:n / n)
    edge = diff(taus.vertex)
    taus = edge / 2 + taus.vertex[-length(taus.vertex)]
    if(weight == "LW") weightval = (taus - taus^2) * edge
    if(weight == "HSN") {
      zeroidx = which(taus.vertex < 0.5)
      weightval = qnorm(taus) * edge
      weightval[zeroidx] = 0
    }
    if(weight == "TSW") {
      zeroidx1 = which(taus.vertex < 0.6)
      zeroidx2 = which(taus.vertex > 0.95) - 1
      zeroidx = c(zeroidx1, zeroidx2)
      weightval = (1-taus)^3 / taus * edge
      weightval[zeroidx] = 0
    }
    scalepar = sum(weightval)
    return(list(taus = taus, scalepar = scalepar, weightval = weightval))
  }
  
  # function to obtain the GQTE estimator
  theta.orderstat = function(quantinfo, y){
    y = sort(y, decreasing = FALSE)
    W.LW = quantinfo[[1]]$weightval; W.HSN = quantinfo[[2]]$weightval; W.TSW = quantinfo[[3]]$weightval
    S.LW = quantinfo[[1]]$scalepar; S.HSN = quantinfo[[2]]$scalepar; S.TSW = quantinfo[[3]]$scalepar
    theta.LW = t(W.LW)%*%y/S.LW; theta.HSN = t(W.HSN)%*%y/S.HSN; theta.TSW = t(W.TSW)%*%y/S.TSW
    return(list(theta.LW=theta.LW, theta.HSN=theta.HSN, theta.TSW=theta.TSW))
  }
  
  if(is.element(weight, c("LN", "adaptive"))){
    temp_test = t.test(Y~Z)
    test_stat.LN = -temp_test$statistic; pval.LN = temp_test$p.value
    # t.test function compare mean diff in group 0 - group 1, so the test_stat should be reverse
    theta.LN = mean(Y[Z==1]) - mean(Y[Z==0])
  }
  if(weight != "LN"){
    # get the observed quantinfo.
    ob.quantinfo.trt = lapply(weights.abbr[-1], quant.vertex, n = n.trt)
    ob.quantinfo.ctl = lapply(weights.abbr[-1], quant.vertex, n = n.ctl)
    # calculate theta for both treatment group with diff. weights
    theta.trt = theta.orderstat(ob.quantinfo.trt, y.trt)
    theta.ctl = theta.orderstat(ob.quantinfo.ctl, y.ctl)
    theta.LW = as.numeric(theta.trt$theta.LW - theta.ctl$theta.LW)
    theta.HSN = as.numeric(theta.trt$theta.HSN - theta.ctl$theta.HSN)
    theta.TSW = as.numeric(theta.trt$theta.TSW - theta.ctl$theta.TSW)
    
    set.seed(seed)
    for (i in 1:bptime) {
      repeat{
        bindex = sample(1:n, n, replace = TRUE)
        boot.Y = Y[bindex]; boot.Z = Z[bindex]
        boot.y.trt = boot.Y[boot.Z==1]
        boot.y.ctl = boot.Y[boot.Z==0]
        boot.n.trt = length(boot.y.trt); boot.n.ctl = length(boot.y.ctl)
        if(boot.n.trt>=n0 & boot.n.ctl>=n0) break
      }
      bquantinfo.trt = lapply(weights.abbr[-1], quant.vertex, n = boot.n.trt)
      bquantinfo.ctl = lapply(weights.abbr[-1], quant.vertex, n = boot.n.ctl)
      
      btheta.trt = theta.orderstat(bquantinfo.trt, boot.y.trt)
      btheta.ctl = theta.orderstat(bquantinfo.ctl, boot.y.ctl)
      btheta.LW[i] = btheta.trt$theta.LW - btheta.ctl$theta.LW
      btheta.HSN[i] = btheta.trt$theta.HSN - btheta.ctl$theta.HSN
      btheta.TSW[i] = btheta.trt$theta.TSW - btheta.ctl$theta.TSW
    }
    sd.boot.LW = sd(btheta.LW); test_stat.LW = theta.LW / sd.boot.LW
    sd.boot.HSN = sd(btheta.HSN); test_stat.HSN = theta.HSN / sd.boot.HSN
    sd.boot.TSW = sd(btheta.TSW); test_stat.TSW = theta.TSW / sd.boot.TSW
    pval.boot.LW = 2 * pnorm(-abs(test_stat.LW))
    pval.boot.HSN = 2 * pnorm(-abs(test_stat.HSN))
    pval.boot.TSW = 2 * pnorm(-abs(test_stat.TSW))
  }
  
  if(weight == "LN") re = list(pval = pval.LN, test_stat = test_stat.LN, theta = theta.LN, 
                               weight = weight, base.dat = base.dat)
  if(weight == "LW") re = list(pval = pval.boot.LW, test_stat = test_stat.LW, theta0 = theta.LW,
                               btheta = btheta.LW, weight = weight, bptime = bptime,
                               seed = seed, base.dat = base.dat)
  if(weight == "HSN") re = list(pval = pval.boot.HSN, test_stat = test_stat.HSN, theta0 = theta.HSN,
                                btheta = btheta.HSN, weight = weight, bptime = bptime,
                                seed = seed, base.dat = base.dat)
  if(weight == "TSW") re = list(pval = pval.boot.TSW, test_stat = test_stat.TSW, theta0 = theta.TSW,
                                btheta = btheta.TSW, weight = weight, bptime = bptime,
                                seed = seed, base.dat = base.dat)
  if(weight == "adaptive"){
    pval.boot = c(pval.LN, pval.boot.LW, pval.boot.HSN, pval.boot.TSW)
    test_stat.boot = c(test_stat.LN, test_stat.LW, test_stat.HSN, test_stat.TSW)
    theta = c(theta.LN, theta.LW, theta.HSN, theta.TSW)
    
    summary.info = rbind(pval.boot, test_stat.boot, theta)
    colnames(summary.info) = weights.abbr
    bidx = which.max(abs(test_stat.boot))
    pval.boot = min(pval.boot[bidx]*4, 1)
    test_stat.boot = test_stat.boot[bidx]
    theta.boot = theta[bidx]
    op.weight.boot = weights.abbr[bidx]
    bptheta = rbind(btheta.LW, btheta.HSN, btheta.TSW)
    re = list(pval = pval.boot, test_stat = test_stat.boot,
              theta.boot = theta.boot, summary.info = summary.info, 
              op.weight.boot = op.weight.boot, bptheta = bptheta, weight = weight, 
              bptime = bptime, seed = seed, base.dat = base.dat)
  }
  return(re)
}
