### A Generalized Quantile Method for Subgroup Identification
### Author: Xiang Peng
###         Department of Statistics, George Washington University
### Last Modified On: Jan. 6th, 2022
source("Functions_GQ.R")

GQ_tree = function(dataset, minsplit = 60, minbucket = round(minsplit/4), maxdepth = 3,
                     score, trim = NULL, tau.pt = NULL, quantile.pt = 1:19 * 0.05, 
                     node.var = rep(NA, maxdepth), node.pt = rep(NA, maxdepth), 
                     frame = c(rep(NA, (2*maxdepth)), paste(nrow(dataset)), "0"), L = 0){
  # dataset: first column is the treatment indicator Z, the second column is reseponse y, 
  #          the rest are the candidate split variables
  # minsplit: minimum sample size for a parent node
  # minbucket minimum sample size for one tretment group in the two child nodes
  # maxdepth: depth of the tree
  # score: score function used in the rank test (including the "adaptive" method)
  # trim: optional trimming parameters – only applicable for the Wilcoxon score
  # tau.pt: quantile grids used in the composite quantile estimation
  # quantile.pt: quantile grids for generating split points of continuous split variables
  # frame: tree structure info.
  # L: tree depth
  dataset = as.data.frame(dataset)
  Z = dataset$Z; Y = dataset$Y; nobj = nrow(dataset); result = list()
  
  if(nobj < minsplit){
    print("stop due to node size"); result$frame = rbind(frame, NULL) 
  }else{
    if(L < maxdepth){
      split.var = sp.var.selection(dataset, score, trim)
      var.idx = which.min(split.var$pval) + 2; sv = dataset[, var.idx]
      posi.split.pt = posi.pt(sv, quantile.pt, Y, Z)
      pt.selection = sp.pt.selection(Y, Z, sv, tau.pt, posi.pt = posi.split.pt, minbucket = minbucket)
      split.pt = pt.selection$sp
      if(is.na(split.pt)) {
        print("no split point found due to node size")
        result$frame = rbind(frame, NULL) 
      } else {
        L.node.idx = pt.selection$L.idx
        L.y = Y[L.node.idx]; L.Z = Z[L.node.idx]
        R.y = Y[-L.node.idx]; R.Z = Z[-L.node.idx]
        var_cur = node.var; var_cur[L+1] = colnames(dataset)[var.idx]
        pt_cur_L = pt_cur_R = node.pt
        if(is.factor(sv)){
          pt_cur_L[L+1] = split.pt
          L_level = na.omit(str_extract(split.pt, levels(sv)))
          sv_level = unique(as.numeric(as.character(sv)))
          left_level = as.numeric(as.character(L_level))
          R_level = sv_level[is.na(charmatch(sv_level, left_level))]
          pt_cur_R[L+1] = paste(R_level, collapse = "&")
        }
        if(!is.factor(sv)){
          pt_cur_L[L+1] = paste(split.pt, "-", sep = "")
          pt_cur_R[L+1] = paste(split.pt, "+", sep = "")
        }
        
        result$frame = rbind(frame, c(
          var = var_cur,
          point = pt_cur_L,
          n = length(L.node.idx),
          L = L + 1), c(
            var = var_cur,
            point = pt_cur_R,
            n = nobj - length(L.node.idx),
            L = L + 1  
          )) 
        
        leftnode = dataset[L.node.idx,]
        result <- GQ_tree(
          dataset = leftnode, minsplit = minsplit, minbucket = minbucket, maxdepth = maxdepth,
          score = score, trim = trim, tau.pt = tau.pt,  
          quantile.pt = quantile.pt, node.var = var_cur, node.pt = pt_cur_L, frame = result$frame, L = L+1)
        
        rightnode = dataset[-L.node.idx, ]
        result <- GQ_tree(
          dataset = rightnode, minsplit = minsplit, minbucket = minbucket, maxdepth = maxdepth,
          score = score, trim = trim, tau.pt = tau.pt, 
          quantile.pt = quantile.pt, node.var = var_cur, node.pt = pt_cur_R, frame = result$frame, L = L+1)
      } 
    }else {
      print("stop due to tree level"); result$frame = rbind(frame, NULL) 
    }
  }
  rownames(result$frame) = NULL
  return(result)
}


send_down = function(dat, tree.frame, maxdepth = 3){
  # send a dataset down to each internal nodes of a tree
  noderowindex = function(nodeinfo, maxdepth, dat){
    if(is.na(nodeinfo[1])){
      nodeindex = 1:nrow(dat)
    }else{
      var.name = colnames(dat); factorvar = sapply(dat, is.factor)
      ### get the column idx of split var.
      var_cidx = na.omit(nodeinfo[1:maxdepth])
      var_cidx = charmatch(var_cidx, var.name)
      pt.info = na.omit(nodeinfo[(maxdepth + 1):(2 * maxdepth)])
      nodelevel = length(var_cidx)
      nodeindex = rep(1, nrow(dat))
      
      for (i in 1:nodelevel) {
        temp.var = factorvar[var_cidx[i]]
        if(temp.var) {
          split_pt = na.omit(str_extract(pt.info[i], levels(dat[, var_cidx[i]])))
          split_sign = "ca"
        }else{
          split_pt = as.numeric(str_sub(pt.info[i], end = -2))
          split_sign = str_sub(pt.info[i], -1)
        }
        if(split_sign == "+") nodeindex = nodeindex * I(dat[, var_cidx[i]] > split_pt)
        if(split_sign == "-") nodeindex = nodeindex * I(dat[, var_cidx[i]] <= split_pt)
        if(split_sign == "ca") nodeindex = nodeindex * (!is.na(charmatch(dat[, var_cidx[i]], split_pt)))
      }
      
      nodeindex = which(nodeindex ==1)
    }
    return(nodeindex)
  }
  
  node.idx = list()
  if(is.null(tree.frame)) node.idx = NA
  if(!is.null(tree.frame)){
    if(nrow(tree.frame) == 1) node.idx[[1]] = noderowindex(tree.frame, maxdepth, dat)
    if(nrow(tree.frame) > 1) node.idx = apply(tree.frame, 1, noderowindex, maxdepth = maxdepth, dat = dat)
  }
  return(node.idx)
}


GQ_validation = function(dat, testdat, tree, weight, p.value = 0.05, maxdepth = 3, 
                           bptime = 500, seed = 314, n0 = 5){
  # dat: training data for generating the tree
  # testdat: validation data for subgroup selection and confirmation
  # weight: weight function considered in the GQTE test
  # p.value: overall type I error
  # tree: the resulting tree from GQ_tree
  TREE = tree$frame; result = list()
  result$dat = dat; result$testdat = testdat; result$TREE = TREE
  train_pval = c()
  
  dat_ridx = send_down(dat, TREE, maxdepth = maxdepth)
  
  for (j in 1:nrow(TREE)) {
    tempidx = dat_ridx[[j]]
    train_pval[j] = GQTE_test(dat$Y[tempidx], dat$Z[tempidx], bptime = bptime, weight = weight,
                              seed = seed, n0 = n0)$pval
  }
  # Boferroni adjustment
  train_pval = pmin(train_pval * nrow(TREE), 1)
  result$train_pval = train_pval
  
  if(any(train_pval < p.value)){
    candidate_grp = subset(TREE, train_pval < p.value)
    n.candidate = nrow(candidate_grp)
    result$candidate = candidate_grp
    test_pval = c(); test_stat = c()
    testdat_ridx = send_down(testdat, candidate_grp, maxdepth = maxdepth)
    for (k in 1:n.candidate) {
      tempidx = testdat_ridx[[k]]
      if(length(tempidx) >= (2*n0)){
        tempZ = testdat$Z[tempidx]
        if(length(which(tempZ == 0)) < 2 | length(which(tempZ == 1)) < 2){
          # for t.test, each trt group must have at least 2 obs.
          test_pval[k] = 1; test_stat[k] = 0
        }else{
          GQtest_re = GQTE_test(testdat$Y[tempidx], testdat$Z[tempidx], bptime = bptime, weight = weight,
                                seed = seed, n0 = n0)
          test_pval[k] = GQtest_re$pval; test_stat[k] = GQtest_re$test_stat
        }
      }else{
        test_pval[k] = 1; test_stat[k] = 0
      }
    }
    # Boferroni adjustment
    test_pval = pmin(test_pval * n.candidate, 1)
    test_pval[is.na(test_pval)] = 1; test_stat[is.na(test_stat)] = 0
    result$test_pval = test_pval
    if(min(test_pval) < p.value) {
      result$confirmed = subset(candidate_grp, test_pval < p.value)
      result$identified = subset(candidate_grp, abs(test_stat) == max(abs(test_stat)))
      ridx = which.max(abs(test_stat)); result$idgrp_testdatidx = testdat_ridx[[ridx]]
    }
    else {
      result$confirmed = NA; result$identified = NA; result$idgrp_testdatidx = NA
    }
  }else{
    result$candidate = NA; result$test_pval = NA; result$confirmed = NA
    result$identified = NA; result$idgrp_testdatidx = NA
  }
  return(result)
}


GQ = function(dat, testdat, minsplit = 60, minbucket = round(minsplit/4), maxdepth = 3,
              score, trim = NULL, tau.pt = NULL, quantile.pt = 1:19 * 0.05,
              node.var = rep(NA, maxdepth), node.pt = rep(NA, maxdepth), 
              frame = c(rep(NA, (2*maxdepth)), paste(nrow(dat)), "0"), L = 0,
              weight, p.value = 0.05, bptime = 500, seed = 314, n0 = 5){
  
  Tree = GQ_tree(dataset = dat, minsplit = minsplit, minbucket = minbucket, maxdepth = maxdepth,
                 score = score, trim = trim, tau.pt = tau.pt, quantile.pt = quantile.pt,
                 node.var = node.var, node.pt = node.pt, frame = frame, L = L)
  
  re = GQ_validation(dat = dat, testdat = testdat, tree = Tree, weight = weight, p.value = p.value, maxdepth = maxdepth,
                     bptime = bptime, seed = seed, n0 = n0)
  
  return(re)
}