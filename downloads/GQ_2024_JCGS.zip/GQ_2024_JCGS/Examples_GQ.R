### Examples
### Author: Xiang Peng
###         Department of Statistics, George Washington University
### Last Modified On: Jan. 6th, 2021

# install required packages (first-time use)
# skip this step if required packages have been installed
install.packages('stringr')
install.packages('quantreg')
install.packages('dagR')

# load functions of the GQ method 
# (the working directory should be the folder containing all the required R files)
source("GQ.R")

##### Split variable selection #####
ntrain = 1000 # sample size
set.seed(314)

Z = rbinom(ntrain, 1, 0.5)
X1 <- as.factor(sample(1:2, ntrain, replace = TRUE))
X2 <- as.factor(sample(1:6, ntrain, replace = TRUE))
X3 <- rnorm(ntrain)
X4 <- rexp(ntrain)
eps_n <- rnorm(ntrain)
Y = 1 + 0.4 * I(X3 > 0)*Z + 0.4 * I(X3 > 0) * Z * eps_n + eps_n
dat_GQ = data.frame(Z=Z, Y=Y, X1 = X1, X2 = X2, X3 = X3, X4 = X4)

# adaptive method
GQ_var_sle(dat_GQ, score = "adaptive")$var
# normal score
GQ_var_sle(dat_GQ, score = "normal")$var
# half normal scale score
GQ_var_sle(dat_GQ, score = "halfnormalscale")$var
# wilcoxon score
GQ_var_sle(dat_GQ, score = "wilcoxon")$var
# trimmed wilcoxon score
GQ_var_sle(dat_GQ, score = "wilcoxon", trim = c(.6, .95))$var


##### Split point selection #####
ntrain = 1000 # sample size
set.seed(314)

Z = rbinom(ntrain, 1, 0.5)
X1 <- as.factor(sample(1:2, ntrain, replace = TRUE))
X2 <- as.factor(sample(1:6, ntrain, replace = TRUE))
X3 <- rnorm(ntrain)
X4 <- rexp(ntrain)
eps_n <- rnorm(ntrain)
Y = 1 + 0.4 * I(X3 > 0)*Z + 0.4 * I(X3 > 0) * Z * eps_n + eps_n
# data contains only one candidate split variable (assume the correct split variable is selected)
dat_GQ = data.frame(Z=Z, Y=Y, X3 = X3) 
GQ_pt_sle(dat_GQ)$cut # cutoff value of X3


##### Subgroup identification #####
ntrain = ntest = 500
set.seed(314)

Z = rbinom(ntrain + ntest, 1, 0.5)
X1 <- as.factor(sample(1:2, ntrain + ntest, replace = TRUE))
X2 <- as.factor(sample(1:6, ntrain + ntest, replace = TRUE))
X3 <- rnorm(ntrain + ntest)
X4 <- rexp(ntrain + ntest)
eps_n <- rnorm(ntrain + ntest)
Y = 1 + I(X3 > 0.5)*(1 + Z) + I(X4 > 0.5) + (1 + 2*I(X3 > 0.5)*Z)*eps_n
dat_GQ = data.frame(Z = Z, Y = Y, X1 = X1, X2 = X2, X3 = X3, X4 = X4)
# divide the entire data into training and testing samples
train.dat = dat_GQ[1:ntrain, ]; test.dat = dat_GQ[-(1:ntrain), ]

# adaptive method
GQ_adaptive_re = GQ(dat=train.dat, testdat=test.dat, minsplit=40, maxdepth=3, score="adaptive",
                    tau.pt=1:19*.05, weight="adaptive", bptime=500, seed = 314, n0 = 5)
GQ_adaptive_re$TREE # resulting tree generated with training data
                    # var: name of the split variables
                    # point: split points associated with the split variables
                    # n: sample size of the subgroup
                    # L: level of the subgroup ('0' corresponds to the root node)
GQ_adaptive_re$train_pval # GQTE test p-values for all nodes based on training data
GQ_adaptive_re$candidate # candidate subgroups selected using training data
GQ_adaptive_re$test_pval # GQTE test p-values for all candidate subgroups based on testing data
GQ_adaptive_re$confirmed # confirmed subgroups using testing data
GQ_adaptive_re$identified # the confirmed subgroup with the most significant GQTE

# specific score and weight functions (half normal scale score and Half-Scale Normal weight)
GQ_HNS_re = GQ(dat=train.dat, testdat=test.dat, minsplit=40, maxdepth=3, score="halfnormalscale",
               tau.pt=1:19*.05, weight="HSN", bptime=500, seed = 314, n0 = 5)
GQ_HNS_re$TREE # resulting tree generated with training data
GQ_HNS_re$train_pval # GQTE test p-values for all nodes based on training data
GQ_HNS_re$candidate # candidate subgroups selected using training data
GQ_HNS_re$test_pval # GQTE test p-values for all candidate subgroups based on testing data
GQ_HNS_re$confirmed # confirmed subgroups using testing data
GQ_HNS_re$identified # the confirmed subgroup with the most significant GQTE
